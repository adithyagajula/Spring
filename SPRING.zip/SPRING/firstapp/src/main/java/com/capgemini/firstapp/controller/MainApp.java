package com.capgemini.firstapp.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.firstapp.beans.Employee;

@RestController
public class MainApp {
	
	@RequestMapping("/hello")
	public String hello() {
		return "helloWorld";
	}
	
	@RequestMapping("/employee")
	public Employee employeeDetails() {
		
		Employee emp = new Employee();
		emp.setId(101);
		emp.setName("adithya");
		emp.setDesignation("analyst");
		emp.setSalary(25000);
		
		return emp;
	}

}
