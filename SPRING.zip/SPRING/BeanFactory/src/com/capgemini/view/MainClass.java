package com.capgemini.view;

import javax.annotation.Resource;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
//import org.springframework.beans.factory.BeanFactory;
//import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
//import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.env.SystemEnvironmentPropertySource;

import com.capgemini.bean.Employee;

public class MainClass {
	public static void main(String[] args) {
		
		ClassPathResource resource = new ClassPathResource("applicationContext.xml");
        BeanFactory factory = new XmlBeanFactory(resource);
		
	
		Employee employee = factory.getBean("employee",Employee.class);
		
		System.out.println(employee.getEmployeeId());
		System.out.println(employee.getName());

		
		
		
	}
}


