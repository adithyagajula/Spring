package com.cap.bean;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Employee  {
	
	private int id;
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Employee() {
		//super();
		System.out.println("from employee constructor");
	}
	
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("from destroy");
		
	}
	
	public void init() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("from init");
		
	}
	
	
	

}
