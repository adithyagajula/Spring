package com.cap.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class MainClass {
	public static void main(String[] args) {
		AbstractApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		applicationContext.registerShutdownHook();
		
		System.out.println("After application context container");
		  Employee employee = applicationContext.getBean("employee", Employee.class);
		  
		  System.out.println(employee.getId());
		  
		  System.out.println(employee.getName());

}
}
