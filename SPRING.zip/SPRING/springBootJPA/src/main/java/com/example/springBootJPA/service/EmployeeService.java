package com.example.springBootJPA.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springBootJPA.model.EmployeeRecord;
import com.example.springBootJPA.repository.EmployeeRepository;

@Service
public class EmployeeService {

	
	  @Autowired  
	    private EmployeeRepository employeeRepository;  
	    public List<EmployeeRecord> getAllEmployees(){  
	        List<EmployeeRecord>employeeRecords = new ArrayList<>();  
	        employeeRepository.findAll().forEach(employeeRecords::add);  
	        return employeeRecords;  
	    }  
	    public Optional<EmployeeRecord> getEmployee(String id){  
	        return employeeRepository.findById(id);  
	    }  
	    public void addEmployee(EmployeeRecord employeeRecord){  
	        employeeRepository.save(employeeRecord);  
	    }  
	    public void delete(String id){  
	        employeeRepository.deleteById(id);  
	        
	    } 
}
