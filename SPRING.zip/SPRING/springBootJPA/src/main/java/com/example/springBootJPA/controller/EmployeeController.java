package com.example.springBootJPA.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.springBootJPA.model.EmployeeRecord;
import com.example.springBootJPA.service.EmployeeService;

@RestController
public class EmployeeController {
	
	
		@Autowired  
	    private EmployeeService employeeService;   
	    
		@RequestMapping("/")  
	    public List<EmployeeRecord> getAllEmployee(){  
	        return employeeService.getAllEmployees();  
	    }     
	    @RequestMapping(value="/add-employee", method=RequestMethod.POST)  
	    public void addEmployee(@RequestBody EmployeeRecord employeeRecord){  
	        employeeService.addEmployee(employeeRecord);  
	    }  
	    @RequestMapping(value="/employee/{id}", method=RequestMethod.GET)  
	    public Optional<EmployeeRecord> getEmployee(@PathVariable String id){  
	        return employeeService.getEmployee(id);  
	    } 
	    
	    @RequestMapping(value="/employee/{id}", method=RequestMethod.DELETE)  
	    public void deleteById(@PathVariable String id) {
	    employeeService.delete(id);  
	    }
	    

}
