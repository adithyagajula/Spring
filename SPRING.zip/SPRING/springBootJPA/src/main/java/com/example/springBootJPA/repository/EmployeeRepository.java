package com.example.springBootJPA.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.springBootJPA.model.EmployeeRecord;

public interface EmployeeRepository extends CrudRepository<EmployeeRecord, String>{

}
