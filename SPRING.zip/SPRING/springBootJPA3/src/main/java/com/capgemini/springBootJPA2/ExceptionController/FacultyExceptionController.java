package com.capgemini.springBootJPA2.ExceptionController;

public class FacultyExceptionController {

}
