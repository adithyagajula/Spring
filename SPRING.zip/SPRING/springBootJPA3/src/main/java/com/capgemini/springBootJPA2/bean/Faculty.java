package com.capgemini.springBootJPA2.bean;

public class Faculty {

}
