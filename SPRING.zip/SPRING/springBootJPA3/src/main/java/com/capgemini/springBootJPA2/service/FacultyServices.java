package com.capgemini.springBootJPA2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.springBootJPA2.bean.FacultyDetails;
import com.capgemini.springBootJPA2.repository.FacultyRepository;

@Service
public class FacultyServices {
	
	 @Autowired
	    private FacultyRepository repo;
	    
	    public List<FacultyDetails> getAll() {
	        return (List<FacultyDetails>) repo.findAll();
	    }
	    
	    
	    public Optional<FacultyDetails> getById(String sessionName ) {
	        return repo.findById(sessionName);
	        
	    }
	    
	    public void addFaculty(FacultyDetails faculty) {
	        repo.save(faculty);
	    }

	 

	    public void delete(String sessionName) {
	        
	        repo.deleteById(sessionName);
	    }
	    
	    
	    
	    public void updateS(String sessionName,FacultyDetails faculty) {
	        repo.deleteById(sessionName);
	        faculty.setSessionName(sessionName);
	     
	        repo.save(faculty);
	        
	    }

}
