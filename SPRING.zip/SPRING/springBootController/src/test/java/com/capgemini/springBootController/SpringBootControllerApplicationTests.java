package com.capgemini.springBootController;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
