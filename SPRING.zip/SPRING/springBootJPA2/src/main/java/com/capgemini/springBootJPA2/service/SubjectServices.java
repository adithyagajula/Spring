package com.capgemini.springBootJPA2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.springBootJPA2.bean.FacultyDetails;
import com.capgemini.springBootJPA2.bean.Subject;
import com.capgemini.springBootJPA2.repository.FacultyRepository;
import com.capgemini.springBootJPA2.repository.SubjectRepository;

@Service
public class SubjectServices {

	 @Autowired
	    private SubjectRepository srepo;
	    
	    public List<Subject> getAll() {
	        return (List<Subject>) srepo.findAll();
	    }
	    
	    
	    public Optional<Subject> getById(String  subjectid ) {
	        return srepo.findById( subjectid);
	        
	    }
	    
	    public void addSubject(Subject subject) {
	        srepo.save(subject);
	    }

	 

	    public void delete(String subjectid) {
	        
	        srepo.deleteById(subjectid);
	    }
	    
	    
	    
	    public void updateS(String subjectid,Subject subject) {
	     //  repo.deleteById(sessionName);
	        //faculty.setSessionName(sessionName);
	     
	        srepo.save(subject);
	        
	    }


}
