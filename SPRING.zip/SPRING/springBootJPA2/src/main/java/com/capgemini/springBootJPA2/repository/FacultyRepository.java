package com.capgemini.springBootJPA2.repository;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.springBootJPA2.bean.FacultyDetails;


public interface FacultyRepository extends CrudRepository<FacultyDetails, String>{

}
