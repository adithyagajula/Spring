package com.capgemini.springBootJPA2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpa2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpa2Application.class, args);
	}

}
