package com.capgemini.springBootJPA2.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springBootJPA2.bean.FacultyDetails;
import com.capgemini.springBootJPA2.bean.Subject;
import com.capgemini.springBootJPA2.service.FacultyServices;
import com.capgemini.springBootJPA2.service.SubjectServices;

@RestController
public class SubjectController {

	@Autowired
	private SubjectServices subjectservice;
	
	@RequestMapping("/subject")
	 public List<Subject> getA() {
        return subjectservice.getAll();
    }
    
    @RequestMapping("/subject{subjectid}")
    public Optional<Subject> get(@PathVariable String subjectid)
    {
        return subjectservice.getById(subjectid);
    }
    
    @PostMapping("/subject")
    public void add(@RequestBody Subject s1) {
    	subjectservice.addSubject(s1);
    }
    
    @DeleteMapping("/subject{sessionName}")
    public void del(@PathVariable String subjectid) {
    	subjectservice.delete(subjectid);
    }
    
    @PutMapping("/subject{subjectid}")
    public void update(@PathVariable String subjectid,@RequestBody Subject s1) {
    	subjectservice.updateS(subjectid, s1);
    }


}
