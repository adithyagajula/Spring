package com.capgemini.springBootJPA2.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Subject {
@Id
private String subjectid;
private String description;
/*@OneToOne
private FacultyDetails sessionName;*/
public String getSubjectid() {
	return subjectid;
}
public void setSubjectid(String subjectid) {
	this.subjectid = subjectid;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
/*public FacultyDetails getSessionName() {
	return sessionName;
}
public void setSessionName(FacultyDetails sessionName) {
	this.sessionName = sessionName;
}*/
public Subject(String subjectid, String description) {
	super();
	this.subjectid = subjectid;
	this.description = description;
}
public Subject() {
	super();
	// TODO Auto-generated constructor stub
}
	

}
