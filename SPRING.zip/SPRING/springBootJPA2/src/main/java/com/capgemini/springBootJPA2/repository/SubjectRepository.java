package com.capgemini.springBootJPA2.repository;

import org.springframework.data.repository.CrudRepository;


import com.capgemini.springBootJPA2.bean.Subject;

public interface SubjectRepository extends CrudRepository<Subject, String>{

}
