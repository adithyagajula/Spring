package com.capgemini.springBootJPA2.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springBootJPA2.bean.FacultyDetails;
import com.capgemini.springBootJPA2.service.FacultyServices;

@RestController
public class FacultyController {
	
	@Autowired
	private FacultyServices facultyService;
	
	@RequestMapping("/faculty")
	 public List<FacultyDetails> getA() {
        return facultyService.getAll();
    }
    
    @RequestMapping("/faculty{sessionName}")
    public Optional<FacultyDetails> get(@PathVariable String sessionName)
    {
        return facultyService.getById(sessionName);
    }
    
    @PostMapping("/faculty")
    public void add(@RequestBody FacultyDetails f1) {
        facultyService.addFaculty(f1);
    }
    
    @DeleteMapping("/faculty{sessionName}")
    public void del(@PathVariable String sessionName) {
        facultyService.delete(sessionName);
    }
    
    @PutMapping("/faculty{sessionName}")
    public void update(@PathVariable String sessionName,@RequestBody FacultyDetails f1) {
        facultyService.updateS(sessionName, f1);
    }

}
