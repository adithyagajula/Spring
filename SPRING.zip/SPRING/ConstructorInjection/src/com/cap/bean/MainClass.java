package com.cap.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class MainClass {
	public static void main(String[] args) {
		ApplicationContext app= new ClassPathXmlApplicationContext("applicationContext.xml");
	HelloWorld hello = (HelloWorld)app.getBean("hello");
	HelloWorld hello1 = (HelloWorld)app.getBean("hello1");
//		
//		
//		System.out.println(hello.getId());
//		System.out.println(hello.getStr());
//		
//		System.out.println(hello1.getId());
//		System.out.println(hello1.getStr());
//		
//		
		System.out.println(hello);
		System.out.println(hello1);
		
		
		
	}

}
