package com.cap.bean;

public class HelloWorld {
	@Override
	public String toString() {
		return "HelloWorld [id=" + id + ", str=" + str + "]";
	}

	private int id;
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	private String str;

	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}

	public HelloWorld(int id, String str) {
		super();
		this.id = id;
		this.str = str;
	}

	public HelloWorld() {
		super();
		
		System.out.println("constructor");
		
	}
	
	public HelloWorld(String str , int id) {
		super();
		this.id = id;
		this.str = str;
	}
	

}
