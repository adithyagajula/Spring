package com.capgemini;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.HelloWorld;;

public class MainApp {
	public static void main(String[] args) {
		
		ApplicationContext app= new ClassPathXmlApplicationContext("applicationContext.xml");
		HelloWorld hello = (HelloWorld)app.getBean("hello");
		
		
		
		System.out.println(hello.getStr());
	}

}
