package com.cap.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class MainClass {
	public static void main(String[] args) {
		ApplicationContext app= new ClassPathXmlApplicationContext("applicationContext.xml");
		Employee hello = (Employee)app.getBean("hello");
		
		
		//Address address = (Address)app.getBean("address");
		System.out.println(hello.getId());
		System.out.println(hello.getName()); 
		System.out.println(hello.getAddress().getCity());
		
		
		
		
		
	}

}
