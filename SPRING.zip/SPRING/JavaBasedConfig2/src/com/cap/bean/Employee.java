package com.cap.bean;


public class Employee  {
	

	private String name;
	

	
	
	
	public Employee() {
		super();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
		
	}
	
	
	


