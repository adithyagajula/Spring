package com.cap.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;



public class MainClass {
	public static void main(String[] args) {
		ApplicationContext app = new AnnotationConfigApplicationContext(EmployeeConfig.class);
		
		
	
		  Employee employee = app.getBean( Employee.class);
		
		  employee.setName("adithya");
		  System.out.println(employee.getName());
		  
		
}
}

